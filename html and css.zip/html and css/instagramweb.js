// Switch between login and signup forms
function switchToSignup() {
  document.getElementById('login-form').style.display = 'none';
  document.getElementById('signup-form').style.display = 'block';
}

function switchToLogin() {
  document.getElementById('signup-form').style.display = 'none';
  document.getElementById('login-form').style.display = 'block';
}

// Validation for login form
function validateLogin() {
  var email = document.getElementById('login-email').value;
  var password = document.getElementById('login-password').value;

  if (email === "" || password === "") {
    alert("Please fill in all fields.");
    return false;
  }

  // Mock login check (In a real scenario, you'd validate the credentials on the server)
  if (email !== "user@domain.com" || password !== "password123") {
    alert("Invalid email or password.");
    return false;
  }

  alert("Login successful!");
  return true;
}

// Validation for signup form
function validateSignup() {
  var username = document.getElementById('signup-username').value;
  var email = document.getElementById('signup-email').value;
  var password = document.getElementById('signup-password').value;

  if (username === "" || email === "" || password === "") {
    alert("Please fill in all fields.");
    return false;
  }

  // Mock signup check (In a real scenario, you'd send the data to the server)
  alert("Account created successfully!");
  return true;
}
